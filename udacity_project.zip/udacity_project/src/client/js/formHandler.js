function handleSubmit(event) {
    event.preventDefault()
//alert('testet one')
    // check what text was put into the form field
    let formText = document.getElementById('name').value
    Client.checkForName(formText)
    const text = formText;
    
console.log(text);
fetch("http://localhost:8009/api", {
  method: "POST",
  mode: "cors",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({ text })
})
.then(res => res.json())
.then(function(res) {
  
      //alert(res.polarity)
      
        document.getElementById("txt_polarity").innerHTML = res.polarity;
        document.getElementById("txt_subjectivity").innerHTML = res.subjectivity;
        document.getElementById("txt_polarity_confidence").innerHTML = res.polarity_confidence;
       document.getElementById("txt_subjectivity_confidence").innerHTML = res.subjectivity_confidence;
      });
    
}
//------------------------------------------------------------------------------
document.getElementById('name').addEventListener('click', gett());
//document.getElementById('generate').addEventListener('click', alert('clicked'));


function gett() {
   
  }
  
  export { handleSubmit };
